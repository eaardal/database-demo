﻿namespace UnitOfWorkImpl
{
    public interface IPersonRepository : IRepository<Person>
    {
    }
}