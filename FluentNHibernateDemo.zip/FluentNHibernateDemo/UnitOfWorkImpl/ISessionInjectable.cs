namespace UnitOfWorkImpl
{
    public interface ISessionInjectable
    {
    }
}