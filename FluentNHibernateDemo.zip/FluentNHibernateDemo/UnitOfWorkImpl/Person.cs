﻿namespace UnitOfWorkImpl
{
    public class Person
    {
        public virtual int Id { get; set; }
        public virtual string Firstname { get; set; }
        public virtual string Lastname { get; set; }
        public virtual int Age { get; set; }
    }
}