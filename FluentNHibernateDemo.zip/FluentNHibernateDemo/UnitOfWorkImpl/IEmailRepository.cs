﻿namespace UnitOfWorkImpl
{
    public interface IEmailRepository : IRepository<Email>
    {
    }
}